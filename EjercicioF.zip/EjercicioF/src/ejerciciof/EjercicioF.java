/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciof;

/**
 *
 * @author LuisCarlos
 */
public class EjercicioF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean check = true;
        Pizza p;
        while (check) {
            System.out.println("\tBienvenido a LA PIZZERIA");
            System.out.println("Seleccione la Pizza deseada.\n");
            System.out.println("1.Vegetariana\n2.Peperoni\n3.Queso\n\n4.Salir");
            int desicion = 0;
            java.util.Scanner input=new java.util.Scanner(System.in);
            desicion = input.nextInt();
            switch (desicion) {
                
                case 1:
                p=new Vegetariana(); 
                p.preparar();
                    break;
                case 2:
                    p=new Peperoni();
                    p.preparar();
                    break;
                case 3:
                    p=new Queso();
                    p.preparar();
                    break;
                case 4:
                    System.out.println("La pizzeria a su servicio, con 20 años de experiencia");
                    check=false;
                    break;
                default:
                    System.out.println("Entrada invalida");
                    break;
                    
            }
        }
    }

}
