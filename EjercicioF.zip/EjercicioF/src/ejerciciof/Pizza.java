/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciof;

/**
 *
 * @author LuisCarlos
 */
public interface Pizza {

public void preparar();
public void masa();
public void salsas();
public void ingredientes();
public void hornear();
public void cortar();
public void empacar();
}
