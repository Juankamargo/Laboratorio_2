/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciof;

import java.util.ArrayList;

/**
 *
 * @author LuisCarlos
 */
public class Queso implements Pizza{
    
    ArrayList<String> ingredientes;

String masa;
String salsa;

Queso(){
    
        this.ingredientes=new ArrayList<>();
        this.ingredientes.add("Queso mozzarella fresco");
        this.ingredientes.add("Parmesano");
        this.masa="Corteza regular";
        this.salsa="Tomate";
}
    
    @Override
    public void preparar() {
        System.out.println("\nPreparar pizza de queso\n");
        this.masa();
        this.salsas();
        this.ingredientes();
        this.hornear();
        this.cortar();
        this.empacar();
        
    }

    @Override
    public void masa() {
        System.out.println("Preparando masa: " + this.masa);}

    @Override
    public void salsas() {
        System.out.println("Adicionando salsa: "+this.salsa);
    }

    @Override
    public void ingredientes() {
        System.out.println("Adicionando ingredientes:");
        for(String i:this.ingredientes)System.out.println("\t-"+i);
    }

    @Override
    public void hornear() {
        System.out.println("Horneado en 20 minutos");
    }

    @Override
    public void cortar() {
        System.out.println("Corte en 5 minutos");
    }

    @Override
    public void empacar() {
        System.out.println("Empaque Rojo");
    }
   
}
