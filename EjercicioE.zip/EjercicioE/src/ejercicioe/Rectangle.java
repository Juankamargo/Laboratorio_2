/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioe;

/**
 *
 * @author LuisCarlos
 */
public class Rectangle extends Shape{
double width, height;

    public Rectangle(double width, double height) {
        super(4);
        this.width = width;
        this.height = height;
    }
    

    @Override
    double getArea() {
    return width*height;    
    }

    @Override
    double getPerimeter() {
    return (width+height)*2;    
    }
    
}
